# Load the shiny package
library(shiny)

server <- function(input, output) {
  
}