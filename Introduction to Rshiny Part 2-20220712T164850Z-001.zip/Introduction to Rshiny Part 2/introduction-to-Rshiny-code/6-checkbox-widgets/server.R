# Load the packages
library(shiny)
library(ggplot2)

# Load the Costa Rican data.
load("region_household.Rdata")

server <- function(input, output) {
}



 
    

