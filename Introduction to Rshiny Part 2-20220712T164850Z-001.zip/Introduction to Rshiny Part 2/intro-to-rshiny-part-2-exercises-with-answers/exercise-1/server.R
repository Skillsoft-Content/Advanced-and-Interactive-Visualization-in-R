# Load the shiny package. 
library(shiny)

# Load ggplot2 package. 
library(ggplot2)

# Load the `chicago_long` dataset.
load("chicago_long.Rdata")

# Creating the server.
server <- function(input, output) {
}