#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO RSHINY PART 3/INTRO TO RSHINY PART 3 EXERCISE ANSWERS ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#### Exercise 1 ####
# =================================================-

#### Task 1 ####
# Navigate to the 'shiny' folder and the subfolder called 'exercises'. 
# Using the same server script that we created in Exercise 2 of last module, in the `renderPlot` function, add a line to subset the variables that are in the list selected by the user i.e. input$selected_variable.

# Result:
# Set working directory
setwd(data_dir)

# Load the shiny package. 
library(shiny)

# Load ggplot2 package. 
library(ggplot2)

# Load the `chicago_long` dataset.
load("chicago_long.Rdata")

# Creating the server.
server <- function(input, output) {
  output$densityplot<- 
    renderPlot({   #<- function to create plot object to send to UI
      
      # Keep only the regions selected by the user.
      chicago_long = subset(chicago_long,
                            variable %in% input$selected_variable)
      
      # Create density plot. 
      ggplot(chicago_long,               #<- take the dataset
             aes(x = norm_value,         #<- set x value
                 fill = variable)) +     #<- fill with variable
        geom_density(alpha = 0.3) + #<- adjust fill transparency
        facet_wrap (~ variable,     #<- make facets by 'variable'
                    ncol = 3)       #<- set a 3-column grid
      
    }) # end of renderPlot
}# end of server

#================================================-
#### Task 2 ####
# Using the same UI script you created as at the end of Intro to Rshiny - Part 2 - Exercise 2, run the App. 
# Try selecting the variable input. What do you notice this time? 

# Result:
# Our plot changes based on the user input and the plot regenerates each time we click on a checkbox.

#================================================-
#### Task 3 ####
# To the UI, add an action button with the `label` "Submit" and `inputId `"submit" to the UI to trigger the regenerating of the plot. 

# Result:
# Load the shiny package.
library(shiny)

# Define UI for application.
ui<- fluidPage(        #<- fluid pages scale their components in real time to fill all available browser width
  titlePanel("Chicago Census Data"), #<- application title
  checkboxGroupInput("selected_variable", label = h3("Select Variable"),
                     choices = list("Percent House Crowded" = "percent_house_crowded", 
                                    "Percent House Below Poverty " = "percent_house_below_poverty", 
                                    "Percent 16 Unemployed" = "percent_16_unemployed", 
                                    "Percent 25 without Diploma"= "percent_25_without_diploma",
                                    "Percent Dependent" = "percent_dependent",
                                    "Per Capita Income" = "per_capita_income" ,
                                    "Hardship Index" = "hardship_index"), 
                     selected = "percent_house_crowded"),
  # Action button to trigger the event.
  actionButton(inputId = "submit",  #<- input ID
               label = "Submit"),    #<- input label
  
  plotOutput("densityplot")  #<- `densityplot` from server converted to output element
) #<- end of fluidPage

#================================================-
#### Task 4 ####
# To the server script, add the `observeEvent` outside the renderPlot function to observe when the submit button is clicked using the value `input$submit`. 
# Using the `isolate` function, keep the `renderPlot` function from regenerating unless the submit button is clicked. 
# Run the App. Try selecting a variable input and then clicking the submit button. 

# Result:
# Set working directory.
setwd(data_dir)

# Load the shiny package. 
library(shiny)

# Load ggplot2 package. 
library(ggplot2)

# Load the `chicago_long` dataset.
load("chicago_long.Rdata")

# Creating the server.
server <- function(input, output) {
  
  observeEvent(input$submit,  #<- observe monitors the submit button's value
               
  output$densityplot<- 
    renderPlot({   #<- function to create plot object to send to UI
      isolate({                           #<- function to isolate this part of app from regenerating
      # Keep only the regions selected by the user.
      chicago_long = subset(chicago_long,
                            variable %in% input$selected_variable)
      
      # Create density plot. 
      ggplot(chicago_long,               #<- take the dataset
             aes(x = norm_value,         #<- set x value
                 fill = variable)) +     #<- fill with variable
        geom_density(alpha = 0.3) + #<- adjust fill transparency
        facet_wrap (~ variable,     #<- make facets by 'variable'
                    ncol = 3)       #<- set a 3-column grid
      }) # end of isolate
    }) # end of renderPlot
  ) # end of observeEvent
}# end of server



#### Exercise 2 ####
# =================================================-

#### Task 1 ####
# Navigate to the 'shiny' folder and the subfolder called 'exercises'. 
# Using the same UI script that we used in Exercise 1, add the sidebar layout to our app. 
# Keep the title panel and the checkbook group input in the `sidebarPanel`.
# Keep the plot in the `mainPanel`. 
# Using the same server file as at the end of Exercise 1, run the App. Resize the app window to make it wider so that the plots can be seen more clearly. 

# Result:

# Load the shiny package.
library(shiny)

# Define UI for application.
ui<- fluidPage(        #<- fluid pages scale their components in real time to fill all available browser width
  titlePanel("Chicago Census Data"), #<- application title
  sidebarLayout(                      #<- layout function
    sidebarPanel(
  checkboxGroupInput("selected_variable", label = h3("Select Variable"),
                     choices = list("Percent House Crowded" = "percent_house_crowded", 
                                    "Percent House Below Poverty " = "percent_house_below_poverty", 
                                    "Percent 16 Unemployed" = "percent_16_unemployed", 
                                    "Percent 25 without Diploma"= "percent_25_without_diploma",
                                    "Percent Dependent" = "percent_dependent",
                                    "Per Capita Income" = "per_capita_income" ,
                                    "Hardship Index" = "hardship_index"), 
                     selected = "percent_house_crowded"),
  # Action button to trigger the event.
  actionButton(inputId = "submit",  #<- input ID
               label = "Submit")    #<- input label
    ), #<- end of sidebarPanel
  mainPanel(
    plotOutput("densityplot")  #<- `densityplot` from server converted to output element
  )#<- end of mainPanel 
  ) #<- end of sidebarLayout
) #<- end of fluidPage




