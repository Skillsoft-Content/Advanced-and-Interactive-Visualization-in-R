#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO RSHINY PART 3/INTRO TO RSHINY PART 3 ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 6: Connecting the UI to the server  ####

# Keep only the regions selected by the user.
#`input$region` is a list of regions selected by user.
region_household = subset(region_household,
                          region %in% input$region) 



#=================================================-
#### Slide 7: Connecting the UI to the server  ####

library(shiny)
library(dplyr)
library(ggplot2)
load("region_household.Rdata")
# Define server logic.
server <- function(input, output) {
output$densityplot<- 
  renderPlot({   #<- function to create plot object to send to UI
  # Keep only the regions selected by the user.
  region_household = subset(region_household,
                            region %in% input$region)
  


#=================================================-
#### Slide 8: Connecting the UI to the server  ####

# Create density plot. 
    ggplot(region_household,              #<- set data
           aes(x = total_in_household,    #<- map `x value`
               fill = region )) +         #<- map fill
           geom_density(alpha = 0.3)   +  #<- adjust density fill
           labs(title = "Density of number of people in a household by region") +
           facet_wrap (~ region,          #<- make facets by 'region'
                       ncol = 3)}) }# end of server


#=================================================-
#### Slide 13: Adding the action button to UI  ####

library(shiny)
ui<- fluidPage(        #<- fluid pages scale their components in real time to fill all available browser width
   titlePanel("Costa Rican Data"), #<- application title
   checkboxGroupInput("region", label = h3("Select Region"),
                      choices = list("Antlantica" = "region_antlantica", 
                                     "Brunca" = "region_brunca", 
                                     "Central" = "region_central", 
                                     "Chorotega"= "region_Chorotega",
                                     "Huetar" = "region_huetar",
                                     "Pacifico" = "region_pacifico" 
                                     ), 
                      selected =  "region_antlantica"),
  # Action button to trigger the event.
   actionButton(inputId = "submit",  #<- input ID
                label = "Submit"),   #<- input label
  plotOutput("densityplot")  #<- `scatterplot` from server converted to output element
  ) #<- end of fluidPage



#=================================================-
#### Slide 14: Adding observeEvent() and isolate() to server  ####

# Load the Costa Rican data.
load("region_household.Rdata")
# Define server logic. 
server <- function(input, output) {
  
observeEvent(input$submit,            #<- observe monitors the submit button's value
             
output$densityplot<- 
  renderPlot({                        #<- function to create plot object to send to UI
  isolate({                           #<- function to isolate this part of app from regenerating
  # Keep only the regions selected by the user.
  region_household = subset(region_household,
                            region %in% input$region) #<- `input$region` is a list of regions selected by user


#=================================================-
#### Slide 15: Adding observeEvent() and isolate() to server (cont'd)  ####

  # Create density plot. 
    ggplot(region_household,              #<- set data
           aes(x = total_in_household,    #<- map `x value`
               fill = region )) +         #<- map fill
           geom_density(alpha = 0.3)   +  #<- adjust density fill
           labs(title = "Density of number of people in a household by region") +
           facet_wrap (~ region,          #<- make facets by 'region'
                       ncol = 3)          #<- set a 3-column grid
  }) # end of isolate
 }) # end of renderPlot
) # end of observeEvent
}# end of server


#=================================================-
#### Slide 18: Exercise 1  ####




#=================================================-
#### Slide 21: Panels and layouts in Shiny  ####

conditionalPanel()
fixedPanel()
inputPanel()
mainPanel()
navlistPanel()
sidebarPanel()
titlePanel()
tabPanel()
tabsetPanel()
?panel_name


#=================================================-
#### Slide 24: Adding sidebarLayout() to our app: UI  ####

library(shiny)

# Define UI for application.
ui<- fluidPage(    
    #<- fluid pages scale their components in realtime to fill all available browser width
   titlePanel("Costa Rican Data"), #<- application title
   sidebarLayout(                      #<- layout function
    sidebarPanel(
      checkboxGroupInput("region", label = h3("Select Region"),
                      choices = list("Antlantica" = "region_antlantica", 
                                     "Brunca" = "region_brunca", 
                                     "Central" = "region_central", 
                                     "Chorotega"= "region_Chorotega",
                                     "Huetar" = "region_huetar",
                                     "Pacifico" = "region_pacifico" 
                                     ), 
                      selected =  "region_antlantica"),


#=================================================-
#### Slide 25: Adding sidebarLayout() to our app: UI (cont'd)  ####

      actionButton(inputId = "submit",  #<- input ID
                    label = "Submit")  #<- input label
    ), #<- end of sidebarPanel
  mainPanel(
    plotOutput("densityplot")  #<- `densityplot` from server converted to output element
   )#<- end of mainPanel 
  ) #<- end of sidebarLayout
 ) #<- end of fluidPage


#=================================================-
#### Slide 26: Adding sidebarLayout() to our app: server  ####


# Create density plot. 
ggplot(region_household,              #<- set data
       aes(x = total_in_household,    #<- map `x value`
           fill = region )) +         #<- map fill
       geom_density(alpha = 0.3)   +  #<- adjust density fill
       labs(title = "Density of number of people in a household by region") +
       facet_wrap (~ region,          #<- make facets by 'region'
                   ncol = 2)          #<- set a 2-column grid



#=================================================-
#### Slide 30: Exercise 2  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
