#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO RSHINY PART 1/INTRO TO RSHINY PART 1 ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================  -
#### Slide 6: The RShiny package  ####

library(shiny)

help("shiny-package")


#=================================================-
#### Slide 15: Directory settings  ####

# Set `main_dir` to the location of your `skillsoft` folder (for Mac/Linux).
main_dir = "~/Desktop/skillsoft"

# Set `main_dir` to the location of your `skillsoft` folder (for Windows).
main_dir = "C:/Users/[username]/Desktop/skillsoft"

# Make `data_dir` from the `main_dir` and 
# remainder of the path to data directory.
data_dir = paste0(main_dir, "/data")


#=================================================-
#### Slide 16: Set up a base app: UI  ####

# Load the Shiny package.
library(shiny)

# Create UI.
ui <- fluidPage(
 # This is where the code to customize the UI will be included
)


#=================================================-
#### Slide 17: Set up a base app: server.R  ####

# Load the Shiny package
library(shiny)

# Create server 
server <- function(input, output) #<- server always needs to be a function of `input` and `output`
  {
    # Our server does not currently require any logic so we will leave it empty.
  }



#=================================================-
#### Slide 27: HTML tags  ####

shiny::tags

names(tags)


#=================================================-
#### Slide 29: Set up: load the dataset  ####

# Set the working directory to the data directory.
setwd(data_dir)

# Load the dataset and view the first few rows. 
load("region_household.Rdata")


#=================================================-
#### Slide 30: Set up: the dataset  ####

# Top entries of the region_household dataset
head(region_household)


#=================================================-
#### Slide 31: Static density plot based on regions  ####

# This is how our static `ggplot` density plot was created.
density_plot <- 
ggplot(region_household,            #<- set data
       aes(x = total_in_household,  #<- map `x value`
           fill = region )) +       #<- map fill
       geom_density(alpha = 0.3) +  #<- adjust fill transparency
       labs(title =                 #<- add title 
            "Density of number of people by region") +
      facet_wrap (~ region,         #<- make facets by 'region'
                  ncol = 3)         #<- set a 3-column grid


#=================================================-
#### Slide 32:  Static density plot based on regions  ####

density_plot


#=================================================-
#### Slide 33: Adding density plot to our base app: UI  ####

library(shiny)

ui <- fluidPage(
  
  # Title of the app.
  titlePanel("Costa Rican Data"),
  
  # Render the output as plot.
  plotOutput(outputId = "densityplot")
  
)


#=================================================-
#### Slide 34: Adding density plot to our base app: server  ####

library(shiny)
library(dplyr)
library(ggplot2)
# Define server logic. 
server <- function(input, output) {
  load("region_household.Rdata")
output$densityplot<- 
  renderPlot({   #<- function to create plot object to send to UI
  # Create density plot. 
    ggplot(region_household,              #<- set data
           aes(x = total_in_household,    #<- map `x value`
               fill = region )) +         #<- map fill
           geom_density(alpha = 0.3)   +  #<- adjust density fill
           labs(title = "Density of number of people in a household by region") +
           facet_wrap (~ region,          #<- make facets by 'region'
                       ncol = 3)          #<- set a 3-column grid
    }) # end of renderPlot
}# end of server


#=================================================-
#### Slide 37: Exercise 1  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
