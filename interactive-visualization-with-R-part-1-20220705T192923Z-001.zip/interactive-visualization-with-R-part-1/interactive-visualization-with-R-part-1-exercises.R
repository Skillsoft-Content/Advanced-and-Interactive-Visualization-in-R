#######################################################

#######################################################

############    COPYRIGHT - DATA SOCIETY   ############

#######################################################

#######################################################



## INTERACTIVE VISUALIZATION WITH R PART 1/INTERACTIVE VISUALIZATION WITH R PART 1 EXERCISE ANSWERS ##



## NOTE: To run individual pieces of code, select the line of code and

##       press ctrl + enter for PCs or command + enter for Macs





#### Exercise 1 ####

# =================================================-





#### Task 1 ####



# Set up data:

# Confirm your working directory. Make sure it is set to `data_dir`.

# Load `tidyverse` and `highcharter` packages. 

# Read in "fast_food_data.csv" to a data frame `fast_food`.

# Create a new subset from `fast_food`, named `fast_food_sub`, 

# Select only `Calories` and variables that end in "g.", 

# EXCLUDE variables that start with "Serving" from `fast_food`.



# Result:





#================================================-

#### Task 2 ####



# Set up & specify:

# To make a scatterplot of normalized nutritional components compared to calories,

# we need to convert `fast_food_sub` into a long dataset `FF_subset_long2`

# and normalize the nutrition components.

# Explicitly exclude `Calories` from the gather.

# Use the same code used previously to:

# - change the case of all letters to lower case

# - remove the last character from the end of the nutrition variables

# - replace all remaining . with _ in the variable names

# Then use the group_by & mutate statements to normalize the nutritional values, using the MEAN to normalize.

# Check the top of FF_subset_long2 to confirm you have four columns. What are those column names?

# Result: Calories, variable, value, norm_value







#================================================-

#### Task 3 ####



# Create a scatterplot named ff_inter_scatter using hchart. 

# Plot the normalized values against `Calories` and set the group = variables.

# View `ff_inter_scatter`.



# Result:







#================================================-

#### Task 4 ####



# Use `hc_chart` to specify "xy" zoom for `ff_inter_scatter`.

# Add the title to the plot "Fast Food Data Scatterplot".

# Do you notice any patterns in `trans_fat__g` values by looking at the scatterplot?

# If so, describe what you see and try to interpret it.



# Result:



# The `trans_fat__g` variable has a very distinct pattern, it seems like there are few 

# unique values present in this variable, which leads us to a conclusion that

# even though the data is encoded as numeric it is actually categorical data.

# Uncovering patterns like this is exactly why we should do EDA and plot our data

# before running any analyses as it may affect the output of our algorithms and models.



#================================================-

#### Task 5 ####



# Create a version of `fast_food_sub`, named `fast_food_sub2`, 

# that has dropped all rows with NA values. 

# Then create a correlation matrix, named cor_matrix2, that includes all columns of `fast_food_sub2` except Calories.

# Plot `cor_matrix2` using hchart and assign it to `correlation_interactive2`.



# Result:









#### Exercise 2 ####

# =================================================-





#### Task 1 ####



# Save the output of `summary(fast_food_sub2)` to `ffood_summary` and a data frame object.

# Then inspect `ffood_summary`.

# Remove `Var1` from `ffood_summary` and rename the remaining columns to be "Variable" and "Summary".

# Inspect `ffood_summary` after you make those changes.



# Result: 



# Create data summary.



# Save it as a data frame.



# Inspect the data.



# Remove an empty variable.



# Rename remaining columns.



# Inspect updated data.



#================================================-

#### Task 2 ####



# Replicate the transformation used in the class slides to separate 

# the `Summary` column into two different columns.

# You want the statistic and the value to be in different columns.

# And convert the applicable data to numeric, rather than character.

# What separator will you use to split the column into two?

# Use `subset` to retain only values that are not NA.



# Result:

# Separator should be ":" and the number of rows in the `ffood_summary` is 63



# Transformation using tidyr



# Subset only rows where `Value` is not NAs.



#================================================-

#### Task 3 ####



# Construct the summary chart `ffood_summary_interactive` using `hchart`.

# Add the setting to share tooltip.

# View `ffood_summary_interactive`.

# What's off about this chart? 

# What's wrong with Sodium? 

# What should we have done before summarizing the data?



# Result: 

# Sodium looks larger than everything else because of the units of measurement. 

# We should have scaled all the data to the same scale, or transformed sodium to grams.











#================================================-

#### Task 4 ####



# Create boxplot using `FF_subset_long2` from exercise 1, using `hchart()`.

# Save it as `ff_bp_interactive`.



# Result:





#================================================-

#### Task 5 ####



# Enhance the boxplot options using `hc_plotOptions` to color each box plot.

# Add the title "Fast Food Data Boxplot" to the plot.

# View the plot.



# Result:



# Enhance original boxplot with some options.







#================================================-

#### Task 6 ####



# Load the `htmlwidgets` package.

# Using `saveWidget` command, save the boxplot to `plot_dir`.

# Save the widget with the name "interactive_boxplot.html".



# Result:

# Set working directory to where you save plots.





# Save desired interactive plot to an HTML file.










